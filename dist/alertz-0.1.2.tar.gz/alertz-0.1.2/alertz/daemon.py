# ~/dev/py/alertz/alertz/daemon.py

__all__ = [ 'runTheDaemon',
          ]

import socket, sys
import serverutil
from io                 import StringIO

import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T

from alertz import *
from alertzProtoSpec    import ALERTZ_PROTO_SPEC
from fieldz.parser      import StringProtoSpecParser
from fieldz.chan        import Channel
from fieldz.msgImpl     import makeMsgClass, makeFieldClass

BUFSIZE         = 16*1024       # must allow for all using protocols
ALERTZ_MAX_MSG  = 512           # the maximum number of bytes in a message
ALERTZ_PORT     = 55555

# SYNTACTIC MACHINERY -----------------------------------------------
protoText   = StringIO(ALERTZ_PROTO_SPEC)       # file-like
p           = StringProtoSpecParser(protoText)
sOM         = p.parse()                 # object model from string serialization
protoName   = sOM.name                  # the dotted name of the protocol

# XXX should be possible to get the class by string name
ZoneMismatchMsg = makeMsgClass(protoName, sOM.msgs[0])
CorruptListMsg  = makeMsgClass(protoName, sOM.msgs[1])
ShutdownMsg     = makeMsgClass(protoName, sOM.msgs[2])

# DAEMON ------------------------------------------------------------
def actuallyRunTheDaemon(options):
    verbose     = options.verbose
    s           = None
    (cnx, addr) = (None, None)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', options.port))
    s.listen(1)
    try:
        running = True
        while running:
            print "WAITING FOR CONNECTION"              # DEBUG
            cnx, addr = s.accept()
            try:
                acceptMsg = "CONNECTION FROM %s" % str(addr)
                if verbose:
                    print acceptMsg
                print "BRANCH TO options.accessLog.log()"  ; sys.stdout.flush()
                options.accessLog.log(acceptMsg)
                print "BACK FROM options.access.log()"  ; sys.stdout.flush()

                while 1:
                    print "BRANCH TO cnx.recv"  ; sys.stdout.flush()

                    # WHAT GETS PARSED:
                    data = cnx.recv(ALERTZ_MAX_MSG)
                    if not data:
                        # XXX we should log null messages
                        continue

                    # We need to look at the message header to decide
                    # whether we have all the data and to learn the
                    # message type.
                    
                    # XXX STUB: if there isn't enough data to include
                    # the header, discard: we close the connection and 
                    # continue

                    # XXX STUB: if the message is incomplete, wait a very
                    # short time, discard and close if not received within
                    # that period
                    
                    # If the data doesn't parse, we just close the 
                    # connection and continue

                    # XXX STUB: parse the data

                    # switch on message type 

                    # XXX WORKING HERE XXX 

                    # DEBUG
                    print "RECEIVED: %s" % data         # DEBUG
                    # END
                    
                    if data.endswith('\r\n'):
                        cnx.sendall('ok\r\n')
                        options.accessLog.log( data[:-2] )
                        if data == 'quit\r\n':
                            break
                        if data == 'shutdown\r\n':
                            running = False
                            break
                    else:
                        errMsg = '%s: %s' % (addr, data)
                        # XXX should log to error.log
                        break # --+
            except KeyboardInterrupt as ke:
                print "<keyboard interrupt received while connection open>"
                # connection will be closed

            finally:
                if cnx: cnx.close()

    except KeyboardInterrupt as ke:
        print "<keyboard interrupt received while listening>"
        # listening socket will be closed
    finally:
        if cnx:
            cnx.close()
        if s:
            s.close()                   # GEEP

def runTheDaemon(options):
    """
    Completes setting up the namespace; if this isn't a "just-show" run,
    creates lock and log managers, creates the logs, and actually runs
    the daemon.
    """
    if options.verbose or options.showVersion or options.justShow:
        print options.pgmNameAndVersion,
    if options.showTimestamp:
        print 'run at %s GMT' % timestamp   # could be prettier
    else:
        print                               # there's a comma up there

    if options.justShow or options.verbose:
        print 'justShow         = ' + str(options.justShow)
        print 'logDir           = ' + str(options.logDir)
        print 'port             = ' + str(options.port)
        print 'showTimestamp    = ' + str(options.showTimestamp)
        print 'showVersion      = ' + str(options.showVersion)
        print 'testing          = ' + str(options.testing)
        print 'timestamp        = ' + str(options.timestamp)
        print 'verbose          = ' + str(options.verbose)

    if not options.justShow:
        lockMgr     = None
        accessLog   = None
        errorLog    = None
        try:
            lockMgr         = serverutil.LockMgr('alertzd')
            logMgr          = serverutil.LogMgr(options.logDir)

            accessLog       = logMgr.open('access')
            options.accessLog  = accessLog
#           # DEBUG -------------------------------------------------
#           print "ACCESS LOG IS %s" % accessLog.logFileName
#           # write to the log file causes core dump XXXXX
#           accessLog.log("opened access log")
#           # END ---------------------------------------------------

            alertzLog       = logMgr.open('alertz')
            options.alertzLog  = alertzLog
#           # DEBUG -------------------------------------------------
#           print "ALERTZ LOG IS %s" % alertzLog.logFileName
#           # write to the log file causes core dump XXXXX
#           alertzLog.log("opened alertz log")
#           # END ---------------------------------------------------

            errorLog        = logMgr.open('error')
            options.errorLog   = errorLog

            # DEBUG -------------------------------------------------
            print "SERVERUTIL VERSION IS %s" % serverutil.__version__
            print "ERROR LOG IS %s" % errorLog.logFileName
            # write to the log file causes core dump XXXXX
            errorLog.log("opened error log")
            # END ---------------------------------------------------

            actuallyRunTheDaemon(options)
        finally:
            try:
                if logMgr:         logMgr.close()
            except Exception as e:  pass
            try:
                if lockMgr:        lockMgr.unlock()
            except Exception as e:  pass                    # GEEP
