#!/usr/bin/python

# testWithDummyClient.py
import os, threading, time
import unittest
from io                 import StringIO

import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T

from rnglib             import SimpleRNG
from alertz             import *
from alertz.daemon      import runTheDaemon
from alertzProtoSpec    import ALERTZ_PROTO_SPEC
from fieldz.parser      import StringProtoSpecParser
from fieldz.chan        import Channel
from fieldz.msgImpl     import makeMsgClass, makeFieldClass

BUFSIZE     = 16*1024                   # huge
rng         = SimpleRNG (time.time())
nextSeqNbr  = 0                         # increment after each use

protoText   = StringIO(ALERTZ_PROTO_SPEC)       # file-like
p           = StringProtoSpecParser(protoText)
sOM         = p.parse()                 # object model from string serialization
protoName   = sOM.name                  # the dotted name of the protocol

ZoneMismatchMsg = makeMsgClass(protoName, sOM.msgs[0])
CorruptListMsg  = makeMsgClass(protoName, sOM.msgs[1])
ShutdownMsg     = makeMsgClass(protoName, sOM.msgs[2])

class TestWithDummyClient (unittest.TestCase):

    def setUp(self):
        pass
    def tearDown(self):
        pass

    # utility functions ---------------------------------------------
    def clearLogs(self):
        if not os.path.exists('logs'):
            os.mkdir('logs')
        self.assertTrue(os.path.exists('logs'))
        files = os.listdir('logs')
        if files:
            print "found %u files" % len(files)
            for file in files:
                os.unlink( os.path.join('logs', file) )
        # excessive paranoia
        files = os.listdir('logs')
        if files:
            self.fail('logs/ has not been cleared')

    # -----------------------------------------------------
    def zoneMismatchFields(self):
        """ returns a list """
        global nextSeqNbr

        timestamp       = int(time.time())
        seqNbr          = nextSeqNbr
        nextSeqNbr     += 1     # used, so increment it

        zoneName        = rng.nextFileName(8)
        expectedSerial  = rng.nextInt32()
        actualSerial    = rng.nextInt32()
        while actualSerial == expectedSerial:
            actualSerial    = rng.nextInt32()

        # NOTE that this is a list
        return [timestamp, seqNbr, zoneName, expectedSerial, actualSerial]

    def nextZoneMismatchMsg(self):
        values = self.zoneMismatchFields()
        return ZoneMismatchMsg(values)
    
    # -----------------------------------------------------
    def corruptListFields(self):
        global nextSeqNbr
        timestamp       = int(time.time())
        seqNbr          = nextSeqNbr
        nextSeqNbr     += 1     # used, so increment it
        remarks         = rng.nextFileName(16)
        return [timestamp, seqNbr, remarks]
    
    def nextCorruptListMsg(self):
        values = self.corruptListFields()
        return CorruptListMsg(values)           # GEEP

    # -----------------------------------------------------
    def shutdownFields(self):
#       global nextSeqNbr
#       timestamp       = int(time.time())
#       seqNbr          = nextSeqNbr
#       nextSeqNbr     += 1     # used, so increment it
        remarks         = rng.nextFileName(16)
        return [remarks,]
    
    def nextCorruptListMsg(self):
        values = self.shutdownFields()
        return ShutdownMsg(values)              # GEEP

    # actual unit test(s) -------------------------------------------

    def testTheDaemon(self):

        MSG_COUNT = 8 + rng.nextInt16(25)   # so 8..32
        # DEBUG
        print "MSG_COUNT = %u" % MSG_COUNT
        # END

        # clear the log files (so delete any files under logs/) -----
        self.clearLogs()

        # start a daemon running in a separate thread ---------------

        # set up options ----------------------------------
        now                 = int (time.time())
        pgmNameAndVersion   = "testWithDummyClient v%s %s" % ( 
                                        __version__, __version_date__)
        with open('/etc/hostname', 'r') as f:
            thisHost = f.read().strip()

        options = {}                           # a namespace, so to speak
        options['ec2Host']         = False
        options['justShow']        = False
        options['logDir']          = 'logs'
        options['pgmNameAndVersion']         = pgmNameAndVersion
        options['port']            = 55555
        options['showTimestamp']   = False
        options['showVersion']     = False
        options['testing']         = False
        options['thisHost']        = thisHost
        options['timestamp']       = now
        options['verbose']         = True # False
        ns = Namespace(options)

        # start the daemon --------------------------------
        daemonT = threading.Thread(target=runTheDaemon, args=(ns,))
        daemonT.start()

        # delay a few ms --------------------------------------------
        time.sleep(0.05)

        # start sending (some fixed number of ) messages ------------
        msgsSent = []
        for n in range(MSG_COUNT):
            msg     = self.zoneMismatchFields()      # a lists
            seqNbr  = msg[1]
            self.assertEquals(n, seqNbr)

            # XXX STUB: send the msg to the daemon

            # open a connection
            # XXX STUB

            # send the message
            # XXX STUB

            # close the connection
            # XXX STUB

            
            msgsSent.append(msg)

        self.assertEquals(MSG_COUNT, len(msgsSent))

        # delay a few ms --------------------------------------------
        time.sleep(0.05)

        # stop the daemon -------------------------------------------
        # XXX NO WAY TO STOP IT!! XXX

        # join the daemon thread ------------------------------------
        daemonT.join()
        # verify that the daemon's logs have the expected contents

        pass

if __name__ == '__main__':
    unittest.main()
