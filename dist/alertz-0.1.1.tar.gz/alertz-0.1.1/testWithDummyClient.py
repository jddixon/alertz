#!/usr/bin/python

# testWithDummyClient.py
import os, threading, time
import unittest
from rnglib import SimpleRNG
from alertz import *

rng         = SimpleRNG (time.time())
nextSeqNbr  = 0                 # increment after each use

class TestWithDummyClient (unittest.TestCase):

    def setUp(self):
        pass
    def tearDown(self):
        pass

    # utility functions ---------------------------------------------
    def clearLogs(self):
        if not os.path.exists('logs'):
            os.mkdir('logs')
        self.assertTrue(os.path.exists('logs'))
        files = os.listdir('logs')
        if files:
            print "found %u files" % len(files)
            for file in files:
                os.unlink( os.path.join('logs', file) )
        # excessive paranoia
        files = os.listdir('logs')
        if files:
            self.fail('logs/ has not been cleared')

    def msgValues(self):
        """ returns a list """
        global nextSeqNbr

        timestamp       = int(time.time())
        seqNbr          = nextSeqNbr
        nextSeqNbr     += 1     # used, so increment it

        zoneName        = rng.nextFileName(8)
        expectedSerial  = rng.nextInt32()
        actualSerial    = rng.nextInt32()
        while actualSerial == expectedSerial:
            actualSerial    = rng.nextInt32()

        # NOTE that this is a list
        return [timestamp, seqNbr, zoneName, expectedSerial, actualSerial]

    # actual unit test(s) -------------------------------------------

    def testTheDaemon(self):

        MSG_COUNT = 8 + rng.nextInt16(25)   # so 8..32
        # DEBUG
        print "MSG_COUNT = %u" % MSG_COUNT
        # END

        # clear the log files (so delete any files under logs/) -----
        self.clearLogs()

        # start a daemon running in a separate thread ---------------
        now                 = int (time.time())
        pgmNameAndVersion   = "testWithDummyClient v%s %s" % ( 
                                        __version__, __version_date__)
        options = {}                           # a namespace, so to speak
        options['justShow']        = False
        options['logDir']          = 'logs'
        options['port']            = 55555
        options['showTimestamp']   = False
        options['showVersion']     = False
        options['testing']         = False
        options['pgmNameAndVersion']         = pgmNameAndVersion
        options['timestamp']       = now
        options['verbose']         = True # False
        ns = Namespace(options)
        # XXX STUB: START THE DAEMON IN ITS THREAD XXX
        daemonT = threading.Thread(target=runTheDaemon, args=(ns,))
        daemonT.start()

        # delay a few ms --------------------------------------------
        time.sleep(0.05)

        # start sending (some fixed number of ) messages ------------
        msgsSent = []
        for n in range(MSG_COUNT):
            msg     = self.msgValues()      # a lists
            seqNbr  = msg[1]
            self.assertEquals(n, seqNbr)

            # XXX STUB: send the msg to the daemon
            
            msgsSent.append(msg)

        self.assertEquals(MSG_COUNT, len(msgsSent))

        # delay a few ms --------------------------------------------
        time.sleep(0.05)

        # stop the daemon -------------------------------------------
        # XXX NO WAY TO STOP IT!! XXX

        # join the daemon thread ------------------------------------
        daemonT.join()
        # verify that the daemon's logs have the expected contents

        pass

if __name__ == '__main__':
    unittest.main()
