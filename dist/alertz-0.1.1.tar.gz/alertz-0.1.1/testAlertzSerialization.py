#!/usr/bin/python

# testAlertzSerialization.py
import time, unittest
from io     import StringIO

from rnglib import SimpleRNG

from fieldz.parser import StringProtoSpecParser
import fieldz.fieldTypes    as F
import fieldz.msgSpec       as M
import fieldz.typed         as T
from fieldz.chan    import Channel
from fieldz.msgImpl import makeMsgClass, makeFieldClass

from alertzProtoSpec       import ALERTZ_PROTO_SPEC

BUFSIZE = 16*1024
rng     = SimpleRNG( time.time() )

class TestAlertzSerialization (unittest.TestCase):

    def setUp(self):
        data = StringIO(ALERTZ_PROTO_SPEC)
        p    = StringProtoSpecParser(data)   # data should be file-like
        self.sOM        = p.parse()     # object model from string serialization
        self.protoName  = self.sOM.name # the dotted name of the protocol

    def tearDown(self):
        pass

    # utility functions #############################################
    def zmmMsgValues(self):
        """ returns a list """
        timestamp       = rng.nextInt32()
        seqNbr          = rng.nextInt32()
        zoneName        = rng.nextFileName(8)
        expectedSerial  = rng.nextInt32()
        actualSerial    = rng.nextInt32()
        while actualSerial == expectedSerial:
            actualSerial    = rng.nextInt32()

        # NOTE that this is a list
        return [timestamp, seqNbr, zoneName, expectedSerial, actualSerial]

    # actual unit tests #############################################

    def testAlertzSerialization(self):
        # -----------------------------------------------------------
        # XXX This code has been crudely hacked from another test 
        # module, and so needs careful review
        # -----------------------------------------------------------

        # verify that this adds 1 (msg) + 3 (field count) to the number
        # of entries in getters, putters, etc
        
        self.assertIsNotNone(self.sOM)
        self.assertTrue(isinstance(self.sOM, M.ProtoSpec))
        self.assertEquals( 'org.xlattice.alertz', self.sOM.name )

        self.assertEquals(0, len(self.sOM.enums) )
        self.assertEquals(2, len(self.sOM.msgs) )
        self.assertEquals(0, len(self.sOM.seqs) )

        msgSpec = self.sOM.msgs[0]
        
        # Create a channel ------------------------------------------
        # its buffer will be used for both serializing # the instance 
        # data and, by deserializing it, for creating a second instance.
        chan = Channel(BUFSIZE)
        buf  = chan.buffer
        self.assertEquals( BUFSIZE, len(buf) )

        # create the ZoneMisMatchMsg class ------------------------------
        ZoneMisMatchMsg     = makeMsgClass(self.protoName, msgSpec)

        # create a message instance ---------------------------------
        values  = self.zmmMsgValues()        # a list quasi-random values
        zmmMsg  = ZoneMisMatchMsg( values )
        
        self.assertEquals(msgSpec.name, zmmMsg.name)
        # we don't have any nested enums or messages
        self.assertEquals(0, len(zmmMsg.enums))
        self.assertEquals(0, len(zmmMsg.msgs))

        self.assertEquals(5, len(zmmMsg.fieldClasses))
        self.assertEquals(5, len(zmmMsg))        # number of fields in instance
        for i in range(len(zmmMsg)):
            self.assertEquals(values[i], zmmMsg[i].value)

        # serialize the object to the channel -----------------------
        zmmMsg.putter(chan)

        # EXPECT THAT a simple message is serialized to the channel with its
        # regID as replacing the fieldNbr in the first varint.  So in 
        # this case we expect the value of the first varints to be
        #   (regID << 3) | LEN_PLUS
        #   msgLen
        # followed by that many bytes.  In this case there are 5 fields,
        # so we expect the data that follows to look like
        #   (0 << 3) | F_UINT32
        #   timestamp
        #   (1 << 3) | V_UINT32
        #   seqNbr
        #   (2 << 3) | L_STRING
        #   zoneName
        #   (3 << 3) | V_UINT32
        #   actualSerial
        #   (4 << 3) | V_UINT32
        #   expectedSerial
        # 
        # The message length will then be about 49 + len(expectedSerial) + len(path)
        
        # XXX WORKING HERE: CONFIRM THAT THE DATA IN THE CHANNEL MATCHES 
        # OUR EXPECTATIONS

        # XXX this has no useful effect:
        chan.limit    = chan.position  
        chan.position = 0

        # deserialize the channel, making a clone of the message ----
#       readBack = ZoneMisMatchMsg.getter(chan) 
#       self.assertIsNotNone(readBack)

#       # verify that the messages are identical --------------------
#       self.assertTrue(zmmMsg.__eq__(readBack))

#       # produce another message from the same values --------------
#       zmmMsg2  = ZoneMisMatchMsg( values )
#       chan2   = Channel(BUFSIZE)
#       zmmMsg2.putter(chan2)
#       copy2   = ZoneMisMatchMsg.getter(chan2)
#       self.assertTrue(zmmMsg.__eq__(copy2))
#       self.assertTrue(zmmMsg2.__eq__(copy2))       # GEEP
        

if __name__ == '__main__':
    unittest.main()
