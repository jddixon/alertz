# ~/dev/py/pzog/pzog/__init__.py

import socket, sys
import serverutil

__version__      = '0.1.1'
__version_date__ = '2012-12-07'

__all__ = [ '__version__', '__version_date__',
            'ALERTZ_MAX_MSG', 'ALERTZ_PORT',
            'Namespace',
            'runTheDaemon',
          ]

# the maximum number of bytes in a message
ALERTZ_MAX_MSG = 512
ALERTZ_PORT    = 55555

# -- NAME SPACE -----------------------------------------------------
# code.activestate.com/recipes/577887-a-simple-namespace-class offers
# a seemingly neat solution, but it just doesn't work
class Namespace(dict):
    def __init__(self, pairs={}):
        super(Namespace, self).__init__(pairs)

    def __getattribute__(self, name):
        try:
            return self[name]
        except KeyError:
            errMsg = "'%s' object has no attribute '%s'" % (
                    type(self).__name__, name)
            raise AttributeError( errMsg )

    def __setattr__(self, name, value):
        self[name] = value

# -- DAEMON ---------------------------------------------------------

def actuallyRunTheDaemon(options):
    verbose = options.verbose

    s = None
    (cnx, addr) = (None, None)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind(('', options.port))
    s.listen(1)
    try:
        running = True
        while running:
            print "WAITING FOR CONNECTION"              # DEBUG
            cnx, addr = s.accept()
            try:
                acceptMsg = "CONNECTION FROM %s" % str(addr)
                if verbose:                     print acceptMsg
                print "BRANCH TO options.accessLog.log()"  ; sys.stdout.flush()
                options.accessLog.log(acceptMsg)
                print "BACK FROM options.access.log()"  ; sys.stdout.flush()
        
                while 1:
                    print "BRANCH TO cnx.recv"  ; sys.stdout.flush()
                    data = cnx.recv(ALERTZ_MAX_MSG)
                    # DEBUG
                    print "RECEIVED: %s" % data         # DEBUG
                    # END
                    if not data:                
                        break
                    if data.endswith('\r\n'):
                        cnx.sendall('ok\r\n')
                        options.accessLog.log( data[:-2] )
                        if data == 'quit\r\n':  
                            break
                        if data == 'shutdown\r\n':
                            running = False
                            break
                    else:
                        errMsg = '%s: %s' % (addr, data)
                        # XXX should log to error.log
                        break # --+
            except KeyboardInterrupt as ke:
                print "<keyboard interrupt received while connection open>"
                # connection will be closed
            
            finally: 
                if cnx: cnx.close()

    except KeyboardInterrupt as ke:
        print "<keyboard interrupt received while listening>"
        # listening socket will be closed
    finally:
        if cnx: 
            cnx.close() 
        if s: 
            s.close()                   # GEEP

def runTheDaemon(options):
    """ 
    Completes setting up the namespace; if this isn't a "just-show" run,
    creates lock and log managers, creates the logs, and actually runs
    the daemon.
    """
    if options.verbose or options.showVersion or options.justShow:
        print options.pgmNameAndVersion,
    if options.showTimestamp:
        print 'run at %s GMT' % timestamp   # could be prettier
    else:
        print                               # there's a comma up there

    if options.justShow or options.verbose:
        print 'justShow         = ' + str(options.justShow)
        print 'logDir           = ' + str(options.logDir)
        print 'port             = ' + str(options.port)
        print 'showTimestamp    = ' + str(options.showTimestamp)
        print 'showVersion      = ' + str(options.showVersion)
        print 'testing          = ' + str(options.testing)
        print 'timestamp        = ' + str(options.timestamp)
        print 'verbose          = ' + str(options.verbose)
        
    if not options.justShow:
        lockMgr     = None
        accessLog   = None
        errorLog    = None
        try:
            lockMgr         = serverutil.LockMgr('alertzd')
            logMgr          = serverutil.LogMgr(options.logDir)
            
            accessLog       = logMgr.open('access')
            options.accessLog  = accessLog
#           # DEBUG -------------------------------------------------
#           print "ACCESS LOG IS %s" % accessLog.logFileName
#           # write to the log file causes core dump XXXXX
#           accessLog.log("opened access log")
#           # END ---------------------------------------------------

            alertzLog       = logMgr.open('alertz')
            options.alertzLog  = alertzLog
#           # DEBUG -------------------------------------------------
#           print "ALERTZ LOG IS %s" % alertzLog.logFileName
#           # write to the log file causes core dump XXXXX
#           alertzLog.log("opened alertz log")
#           # END ---------------------------------------------------

            errorLog        = logMgr.open('error')
            options.errorLog   = errorLog

            # DEBUG -------------------------------------------------
            print "SERVERUTIL VERSION IS %s" % serverutil.__version__
            print "ERROR LOG IS %s" % errorLog.logFileName
            # write to the log file causes core dump XXXXX
            errorLog.log("opened error log")
            # END ---------------------------------------------------

            actuallyRunTheDaemon(options)
        finally:
            try: 
                if logMgr:         logMgr.close()
            except Exception as e:  pass
            try: 
                if lockMgr:        lockMgr.unlock()
            except Exception as e:  pass                    # GEEP
