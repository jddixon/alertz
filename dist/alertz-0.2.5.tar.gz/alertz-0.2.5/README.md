# alertz

Initial commit.

## Project Status

Alpha.  Code and unit tests exist, but some tests fail.

## On-line Documentation

More information on the **alertz** project can be found
[here](https://jddixon.github.io/alertz)
